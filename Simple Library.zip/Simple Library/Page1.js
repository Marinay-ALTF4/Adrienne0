document.addEventListener("DOMContentLoaded", function() {
    console.log("Dashboard loaded!");
});